package projects_day1;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 100;

		System.out.print("Even Numbers from 1 to "+n+" are: ");

		for (int i = 1; i <= n; i++) {

		   //if number%2 == 0 it means its an even number

		   if (i % 2 == 0) {

		 System.out.print(i + " ");
	}

} }}
